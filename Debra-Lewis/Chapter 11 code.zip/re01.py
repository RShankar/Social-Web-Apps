# Python for Informatics, Chapter 11, example 1 (page 129)
# Searches mbox-short.txt for lines that contain the string "From:"
# So, any line containing the string "From:" would match.

import re

hand = open('mbox-short.txt')

for line in hand:
    line = line.rstrip()
    if re.search('From:', line , flags=re.IGNORECASE) :
        print line