# Python for Informatics, Chapter 11, example 5 (page 131, section 11.2)
# searches a string for e-mail addresses (string@string)
# In this case, the findall function should return an array containing:
#   'csev@umich.edu' and 'cwen@iupui.edu'
#    So this program should print: ['csev@umich.edu', 'cwen@iupui.edu']

import re

s = 'Hello from csev@umich.edu to cwen@iupui.edu about the meeting @2PM'
lst = re.findall('\S+@\S+', s)   # \s matches any whitespace character
print lst