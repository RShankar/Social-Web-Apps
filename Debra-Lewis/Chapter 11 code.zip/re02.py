# Python for Informatics, Chapter 11, example 2 (page 130)
# Searches the file for lines that start with the string "From:"
# For example, the line "From: Kaylee@Serenity.com" would match
# but "Hello From: Kaylee@Serenity.com" would NOT match

import re

hand = open('mbox-short.txt')

for line in hand:
    line = line.rstrip()
    if re.search('^From:', line, flags=re.MULTILINE) :
        print line