# Python for Informatics, Chapter 11, example 4 (page 131, section 11.1)
# Searches for Strings that start with "From:" and are followed by one 
# or more characters followed by an @ symbol
# Examples:
# The line "From: stephen.marquard@uct.ac.za"
#     matches "stephen.marquard"
# The line "From: stephen.marquard@uct.ac.za, csev@umic.edu, and cwen@iupui.edu"
#    matches "From: stephen.marquard@uct.ac.za, csev@umic.edu, and cwen"
# '+' expands the previous symbol to match 1 or more times 
# (so '.+' matches any characters 1 or more times)
# Note that the '+' is greedy, and will match as many characters as possible.
# To make it not greedy, and to match as few characters as possible, add '?' after the '+'

import re

hand = open('mbox-short.txt')
for line in hand:
    line = line.rstrip()
    if re.search('^From:.+@', line) :
        print line