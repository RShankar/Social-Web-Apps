# Python for Informatics, Chapter 11, example 9 (page 134, section 11.3)
# Same idea as example 8, but only prints out the numbers from the matched strings
# For example, if this findall were executed on the line "X-blahblah: 1000.2", 
#     it would return "1000.2"

import re
hand = open('mbox-short.txt')
for line in hand:
    line = line.rstrip()
    x = re.findall('^X\S*: ([0-9.]+)',line)
    if len(x) > 0:
        print x